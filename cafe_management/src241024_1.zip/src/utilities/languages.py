all_languages = {
    "en": {
        "title_languages": "English",
        "Welcome": "Hello",
    },
    "vi": {
        "title_languages": "Việt Nam",
        "Welcome": "Xin chào",
    }
}
