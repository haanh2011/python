class Invoice:
    def __init__(self, invoice_date, id_order):
        self.id = id
        self.invoice_date = invoice_date
        self.id_order = id_order

    def update_id(self, id):
        self.id = id